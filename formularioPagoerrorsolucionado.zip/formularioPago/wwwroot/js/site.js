﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.
<script>
    function submitForm() {
        var nombre = document.getElementById("nombre").value;
        var tarjeta = document.getElementById("tarjeta").value;
        var fecha = document.getElementById("fecha").value;
        var cvv = document.getElementById("cvv").value;
        var monto = document.getElementById("monto").value;
        var dias = document.getElementById("dias").value;

        var data = {
            Nombre: nombre,
            Tarjeta: tarjeta,
            Fecha: fecha,
            CVV: cvv,
            Monto: monto,
            Dias: dias
        };

        fetch("tu-archivo-de-procesamiento.aspx", {
            method: "POST",
            body: JSON.stringify(data),
            headers: {
                "Content-Type": "application/json"
            }
        }).then(function(response) {
            console.log(response);
        });
    }
</script>

